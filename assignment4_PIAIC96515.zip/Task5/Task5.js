var myInput = document.getElementById("input");
myInput.onkeyup = function () {
  document.getElementById("output").innerText = `number:${myInput.value}`;
  document.getElementById("roundoff").innerText = `round off value:${Math.round(
    myInput.value
  )}`;

  document.getElementById("floor").innerText = `floor value:${Math.floor(
    myInput.value
  )}`;
  document.getElementById("ceilval").innerText = `ceil value:${Math.ceil(
    myInput.value
  )}`;
};
